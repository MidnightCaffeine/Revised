CREATE DATABASE IF NOT EXISTS `rfid_attendance`;

USE `rfid_attendance`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` tinytext NOT NULL,
  `date_in` date NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `remark` tinytext NOT NULL,
  `instructor` tinytext NOT NULL,
  `subject` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4;

INSERT INTO `attendance` VALUES (63,"Jobert Gosuico Simbre","2022-11-22","10:53:38","10:53:54","On Time","Teacher Instructor Example",""),
(64,"Jobert Gosuico Simbre","2022-11-22","11:19:09","11:19:20","Late","Teacher Instructor Example",""),
(65,"Jobert Gosuico Simbre","2022-11-22","11:32:45","11:34:43","On Time","Teacher Instructor Example",""),
(66,"Jobert Gosuico Simbre","2022-11-22","11:36:14","01:43:08","On Time","Teacher Instructor Example",""),
(67,"Jobert Gosuico Simbre","2022-11-23","11:16:10","00:00:00","On Time","Teacher Instructor Example",""),
(68,"Jobert Gosuico Simbre","2022-11-24","12:10:36","12:21:41","On Time","Teacher Instructor Example",""),
(69,"Jobert Gosuico Simbre","2022-11-24","12:24:54","12:32:40","On Time","Teacher Instructor Example",""),
(70,"Jobert Gosuico Simbre","2022-11-24","12:32:44","12:33:20","Late","Teacher Instructor Example",""),
(71,"Jobert Gosuico Simbre","2022-11-24","12:33:24","12:34:00","Late","Teacher Instructor Example",""),
(72,"Jobert Gosuico Simbre","2022-11-24","12:34:09","12:42:16","Late","Teacher Instructor Example",""),
(73,"Jobert Gosuico Simbre","2022-11-24","12:42:22","12:42:44","Late","Teacher Instructor Example",""),
(74,"Jobert Gosuico Simbre","2022-11-24","12:42:52","12:45:37","Late","Teacher Instructor Example",""),
(75,"Jobert Gosuico Simbre","2022-11-24","12:45:48","12:46:33","Late","Teacher Instructor Example",""),
(76,"Jobert Gosuico Simbre","2022-11-24","12:46:45","12:53:14","Late","Teacher Instructor Example",""),
(77,"Jobert Gosuico Simbre","2022-11-24","12:53:24","01:05:25","Late","Teacher Instructor Example",""),
(78,"Jobert Gosuico Simbre","2022-11-24","01:05:33","01:06:13","On Time","Teacher Instructor Example",""),
(79,"Jobert Gosuico Simbre","2022-11-24","01:06:23","01:15:32","On Time","Teacher Instructor Example",""),
(80,"Jobert Gosuico Simbre","2022-11-24","01:15:46","02:10:07","On Time","Teacher Instructor Example",""),
(81,"Jobert Gosuico Simbre","2022-11-24","02:10:13","02:10:28","On Time","Teacher Instructor Example",""),
(82,"Jobert Gosuico Simbre","2022-11-24","02:10:38","02:11:00","On Time","Teacher Instructor Example",""),
(83,"Jobert Gosuico Simbre","2022-11-24","02:11:42","02:11:59","On Time","Teacher Instructor Example",""),
(84,"Jobert Gosuico Simbre","2022-11-24","02:12:03","02:12:39","On Time","Teacher Instructor Example",""),
(85,"Jobert Gosuico Simbre","2022-11-24","02:12:45","02:18:29","On Time","Teacher Instructor Example",""),
(86,"Jobert Gosuico Simbre","2022-11-24","02:18:35","02:24:35","On Time","Teacher Instructor Example",""),
(87,"Jobert Gosuico Simbre","2022-11-24","02:24:53","02:25:47","On Time","Teacher Instructor Example",""),
(88,"Jobert Gosuico Simbre","2022-11-24","02:25:51","02:25:58","On Time","Teacher Instructor Example",""),
(89,"Jobert Gosuico Simbre","2022-11-24","02:26:40","02:32:34","On Time","Teacher Instructor Example",""),
(90,"Jobert Gosuico Simbre","2022-11-24","02:32:40","02:33:39","On Time","Teacher Instructor Example",""),
(91,"Jobert Gosuico Simbre","2022-11-24","02:33:45","02:37:43","On Time","Teacher Instructor Example",""),
(92,"Jobert Gosuico Simbre","2022-11-24","02:37:51","02:42:34","On Time","Teacher Instructor Example",""),
(93,"Jobert Gosuico Simbre","2022-11-24","02:42:56","02:46:02","On Time","Teacher Instructor Example",""),
(94,"Jobert Gosuico Simbre","2022-11-24","02:46:14","02:46:52","On Time","Teacher Instructor Example",""),
(95,"Jobert Gosuico Simbre","2022-11-24","02:46:56","08:22:26","On Time","Teacher Instructor Example",""),
(96,"Jobert Gosuico Simbre","2022-11-24","08:22:39","08:24:31","On Time","Teacher Instructor Example",""),
(97,"Jobert Gosuico Simbre","2022-11-24","08:24:35","08:24:41","On Time","Teacher Instructor Example",""),
(98,"Jobert Gosuico Simbre","2022-11-24","08:24:57","08:41:44","On Time","Teacher Instructor Example",""),
(99,"Jobert Gosuico Simbre","2022-11-24","08:42:06","08:43:34","On Time","Teacher Instructor Example",""),
(100,"Jobert Gosuico Simbre","2022-11-24","08:45:13","08:47:26","On Time","Teacher Instructor Example",""),
(101,"Jobert Gosuico Simbre","2022-11-24","08:52:48","00:00:00","On Time","Teacher Instructor Example","");


DROP TABLE IF EXISTS `attendance_instructor`;

CREATE TABLE `attendance_instructor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` tinytext NOT NULL,
  `date_in` date NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `remark` tinytext NOT NULL,
  `subject` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

INSERT INTO `attendance_instructor` VALUES (8,"Teacher Instructor Example","2022-11-22","10:45:43","11:36:29","",""),
(9,"Teacher Instructor Example","2022-11-22","11:19:50","11:36:24","",""),
(10,"Teacher Instructor Example","2022-11-22","11:20:29","11:35:52","",""),
(11,"Teacher Instructor Example","2022-11-22","11:22:04","11:35:29","",""),
(12,"Teacher Instructor Example","2022-11-22","11:23:21","11:33:58","",""),
(13,"Teacher Instructor Example","2022-11-22","11:23:39","11:33:11","",""),
(14,"Teacher Instructor Example","2022-11-24","12:10:16","08:37:28","",""),
(15,"Teacher Instructor Example","2022-11-24","08:37:54","08:38:41","",""),
(16,"Teacher Instructor Example","2022-11-24","08:38:45","08:39:52","",""),
(17,"Teacher Instructor Example","2022-11-24","08:39:59","08:45:40","",""),
(18,"Teacher Instructor Example","2022-11-24","08:45:46","08:47:03","",""),
(19,"Teacher Instructor Example","2022-11-24","08:47:07","08:52:25","",""),
(20,"Teacher Instructor Example","2022-11-24","08:52:29","08:52:40","","");


DROP TABLE IF EXISTS `class_list`;

CREATE TABLE `class_list` (
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `time` time NOT NULL,
  `teacher_id` int(11) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `rfid`;

CREATE TABLE `rfid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardid` varchar(250) NOT NULL,
  `logdate` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;

INSERT INTO `rfid` VALUES (37,2348130,1667893879),
(38,2348130,1667893885),
(39,2250590,1669207403),
(40,1609090,1669207460),
(41,1606890,1669207493),
(42,1855000,1669207519),
(43,2152890,1669207546),
(44,2049790,1669207578),
(45,2111690,1669207642),
(46,1717590,1669207673),
(47,1716400,1669207702),
(48,1768290,1669207721),
(49,2348130,1669207745);


DROP TABLE IF EXISTS `rfid_card`;

CREATE TABLE `rfid_card` (
  `card_id` int(11) NOT NULL AUTO_INCREMENT,
  `card_number` int(11) NOT NULL,
  `card_status` tinytext NOT NULL,
  `card_holder` tinytext NOT NULL,
  `card_holder_id` int(11) NOT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `rfid_card` VALUES (2,2348130,"Assigned","Jobert Padilla Simbre","0"),
(5,1768290,"Available","","0");


DROP TABLE IF EXISTS `student_list`;

CREATE TABLE `student_list` (
  `student_id` int(11) NOT NULL,
  `student_firstname` tinytext NOT NULL,
  `student_middlename` tinytext NOT NULL,
  `student_lastname` tinytext NOT NULL,
  `phone` tinytext NOT NULL,
  `year_group` tinyint(4) DEFAULT NULL,
  `department` tinytext DEFAULT NULL,
  `section` tinytext DEFAULT NULL,
  `image` varchar(150) DEFAULT NULL,
  `guardian_email` varchar(255) NOT NULL,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `student_id_fk` FOREIGN KEY (`student_id`) REFERENCES `user_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `student_list` VALUES (113,"Jobert","Gosuico","Simbre","09163218023",4,"BSIT","AP",NULL,"ignacio.khiana13@gmail.com");


DROP TABLE IF EXISTS `studentclasses_list`;

CREATE TABLE `studentclasses_list` (
  `class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  KEY `class_id` (`class_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `subject_list`;

CREATE TABLE `subject_list` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` tinytext NOT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `teacher_list`;

CREATE TABLE `teacher_list` (
  `teacher_id` int(11) NOT NULL,
  `teacher_firstname` tinytext NOT NULL,
  `teacher_middlename` tinytext NOT NULL,
  `teacher_lastname` tinytext NOT NULL,
  `subject_taught` tinytext DEFAULT NULL,
  `department` tinytext DEFAULT NULL,
  `rfid_card_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`),
  CONSTRAINT `teacher_id_fk` FOREIGN KEY (`teacher_id`) REFERENCES `user_list` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `teacher_list` VALUES (112,"Teacher","Instructor","Example",NULL,"BSIT",NULL);


DROP TABLE IF EXISTS `user_list`;

CREATE TABLE `user_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `position` tinytext DEFAULT NULL,
  `card_number` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;

INSERT INTO `user_list` VALUES (57,"admin","$2y$10$jCBPKsCOVo6LKlMHZDOZdOHQ.7Lo3Z2e6ZkLyeYDxI63f7qOfZE0K","admin@example.com","2022-11-01 13:24:14","Administrator","0"),
(112,"teacher1","$2y$10$IdMRLy901/MBIZ6wl5Ntm.I/5WX/VrzLJUYHRFCqWUKTb71Gb1Hea","kljokas@gmail.com","2022-11-24 00:09:04","Instructor",1768290),
(113,"student1","$2y$10$qq4vFOTeyJJItoaaVtVrg..7CGmtB2PMsZcyI.t6qBxFded7bbV/W","jobert.simbre14@gmail.com","2022-11-24 08:39:44","Student",2348130);


SET foreign_key_checks = 1;
